COSCMD
============


A simple command for Cos S3 version.


